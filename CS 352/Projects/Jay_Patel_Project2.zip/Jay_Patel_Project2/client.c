//
//  client.c
//  HW2
//
//  Created by Jay Patel on 10/29/17.
//  Copyright © 2017 Jay Patel. All rights reserved.
//

#include <stdio.h>
#include <unistd.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <openssl/sha.h>
#include <stdio.h>
#include <math.h>

#define PORT 8089


/**
 Prototyping the methods of the code that was provided
 **/
void inplace_reverse(char*str);
int binaryToDecimal(long n);
long decimalToBinary(long n);
void stringToAscii(char *s);
void stringToReverseAscii(char *s);
void stringToEncodedAscii(char *s, int sock);


/*
 At very starting I have Client side code, and at the very bottom I have the code that was provided, I could not access the
 methods from that file in this file. So I decided to just add the code that was provided at the end
 */
int main(int argc, char const *argv[])
{
    
    
    struct sockaddr_in addr_serv;
    int sock = 0;
    
    
    
    
    /**
     
     AF_net is an implementation of the TCP/IP protocol suite for the LINUX
     operating system.
     
     */
    
    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        printf("\n Creation error \n");
        return -1;
    }
    
    memset(&addr_serv, '0', sizeof(addr_serv));
    
    addr_serv.sin_family = AF_INET;
    addr_serv.sin_port = htons(PORT);
    
    
    /*
     
     Converting from text to binary form.
     
     AF_INET: Function converts the character string src into a network
     address structure in the af address family, then copies the network
     address structure to dst.
     
     */
    
    if(inet_pton(AF_INET, "127.0.0.1", &addr_serv.sin_addr) <= 0)
    {
        printf("\nAddress not supported/ Invalid address \n");
        
        return -1;
    }
    
    //checking for connection
    
    if (connect(sock, (struct sockaddr *)&addr_serv, sizeof(addr_serv)) < 0)
    {
        printf("\n Failed to Connect make sure your server is running first \n");
        
        return -1;
    }
    
    /*
     Doing the Hash part here
     */
    
    char buff[1024];
    const unsigned char data[] = "Assig, mrjay!";
    send(sock , "Assig, mrjay!" , 14 , 0);
    recv(sock, buff, 1024, 0);
    
    size_t length = sizeof(data);
    
    char bufa[SHA_DIGEST_LENGTH];
    unsigned char hash[SHA_DIGEST_LENGTH];
    SHA1(data, length, hash);
    for(int i =0; i< SHA_DIGEST_LENGTH; i++)
    {
        sprintf((char*)&(bufa[i*2]), "%02x", hash[i]);
    }
    
    stringToEncodedAscii(bufa , sock);
    
    
}


/**
 Professor code starting here
 **/

//This map structure will be used to store the encodings
//Here, we have used decimal representation of the corresponding 3-bit binary numbers.
int binaryMap[8] = {6,7,5,4,3,2,0,1};
//inplace_reverse takes string as an input and reverses the contentsof the string inplace.
void inplace_reverse(char * str)
{
    if (str)
    {
        char * end = str + strlen(str) - 1;
        // swap the values in the two given variables
        // XXX: fails when a and b refer to same memory location
# define XOR_SWAP(a,b) do\
{\
a ^= b;\
b ^= a;\
a ^= b;\
} while (0)
        // walk inwards from both ends of the string,
        // swapping until we get to the middle
        while (str < end)
        {
            XOR_SWAP(*str, *end);
            str++;
            end--;
        }
# undef XOR_SWAP
    }
}
//binaryToDecimal will return the decimal number for the correspondingbinary form. for eg. decimal [5] for binary [101].
int binaryToDecimal(long n)
{
    int decimalNumber = 0, i = 0, remainder;
    while (n!=0)
    {
        remainder = n%10;
        n /= 10;
        decimalNumber += remainder*pow(2,i);
        ++i;
    }
    return decimalNumber;
}
//decimalToBinary will return the binary form for the correspondingdecimal form. for eg. binary [101] for decimal [5]
long decimalToBinary(long n) {
    int remainder;
    long binary = 0, i = 1;
    
    while(n != 0) {
        remainder = n%2;
        n = n/2;
        binary= binary + (remainder*i);
        i = i*10;
    }
    return binary;
}
//stringToAscii will print ASCII representation of a given string
void stringToAscii(char *s){
    char *ptr = s;
    char finalRes[256]="";
    
    //Go through each character in the string and append thecorrepsonding ASCII representaion to the final result
    while(*ptr){
        int asciiDecimal = (int)*ptr;
        int res = (int) decimalToBinary(asciiDecimal);
        
        char snum[5];
        sprintf(snum, "%d",res);
        strcat(finalRes,snum);
        
        ptr++;
    }
    
    //print the complete ASCII form
    printf("\nstringToAscii:: %s",finalRes);
    return;
}
//stringToReverseAscii will print the reverse ASCII representation ofthe given string
void stringToReverseAscii(char *s){
    char *ptr = s;
    char finalRes[256]="";
    
    //Visit each character in the string and append its ASCII    representation to a temp result
    while(*ptr){
        int asciiDecimal = (int)*ptr;
        int res = (int) decimalToBinary(asciiDecimal);
        
        char snum[5];
        sprintf(snum, "%d",res);
        strcat(finalRes,snum);
        
        ptr++;
    }
    
    //Reverse the temp result to get the final answer
    inplace_reverse(finalRes);
    
    printf("\nstringToReverseAscii:: %s",finalRes);
    return;
}
//stringToEncodedAscii prints the encoded representaion of the ASCIIrepresentaion of a given string(Encoding is based on encoding array atthe top of this file)
void stringToEncodedAscii(char *s, int sock){
    char *ptr = s;
    char finalRes[256]="";
    //First, get the ASCII representation of the given string
    while(*ptr){
        int asciiDecimal = (int)*ptr;
        int res = (int) decimalToBinary(asciiDecimal);
        
        char snum[10];
        sprintf(snum, "%d",res);
        strcat(finalRes,snum);
        
        ptr++;
    }
    
    //Since, we are encoding 3 bits at a time of the ASCII representaion, we need to pad extra 0s to the ASCII string to make
    //its length a multiple of 3.
    int lenOfFinalRes = (int) strlen(finalRes);
    if((lenOfFinalRes % 3) != 0){
        while((lenOfFinalRes % 3) != 0){
            strcat(finalRes,"0");
            lenOfFinalRes++;
        }
    }
    
    //printf("\nString length : %d\n",lenOfFinalRes);
    
    
    char *newPtr = finalRes;
    int j,k;
    char finalResEncoded[256] = "";
    
    //We now take 3 bits at a time, find the encoding from encodingtable at top and append the encoding to a new result string.
    for(j=0;j<(lenOfFinalRes/3);j++){
        char blk[10]= "";
        for(k=0;k<3;k++){
            //printf("\n next : %c\n",*newPtr);
            char ch[2];
            sprintf(ch, "%c",*newPtr);
            strcat(blk,ch);
            newPtr++;
        }
        
        long ret;
        char *ptr1;
        ret = strtol(blk, &ptr1, 10);
        int retI = binaryToDecimal(ret);
        int encodedRet = binaryMap[retI];
        int res = (int)decimalToBinary(encodedRet);
        
        char snum[10];
        sprintf(snum, "%d",res);
        
        //The following is to make sure that, we always have a 3 bitbinary representaion. For eg. decimal 3 is representated as 011 andnot 11
        char paddedStr[10] = "";
        sprintf(paddedStr, "%s","");
        int snumLen = (int)strlen(snum);
        if((snumLen%3) != 0){
            int z;
            for(z=0; z < (3-(snumLen%3)); z++){
                strcat(paddedStr,"0");
            }
        }
        
        strcat(paddedStr,snum);
        
        //printf("\nnormal : %ld ; retI : %d; encodedRet : %d; encoded :%s",ret,retI,encodedRet ,paddedStr);
        strcat(finalResEncoded,paddedStr);
    }
    
    
    char buffer2[1024]; //made a new buffer
    printf("\nstringToEncodedAscii :: %s",finalResEncoded);
    send(sock , finalResEncoded , strlen(finalResEncoded) , 0 ); //using this for the len
    
    //using the buffer in here for the fork
    read(sock , buffer2, 1024);
    printf("%s\n",buffer2);
    
    
    
}

/*
 
 Had to comment it out becuase there were more than one main and wasnt able to compile the code.
 
 int main() {
 char s[256];
 printf("enter the string : ");
 scanf("%s", s);
 
 stringToAscii(s);
 stringToReverseAscii(s);
 stringToEncodedAscii(s);
 return 0;
 }
 */
